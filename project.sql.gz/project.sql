-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 21, 2017 at 07:23 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `table_category`
--

CREATE TABLE IF NOT EXISTS `table_category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `Cat_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `table_category`
--

INSERT INTO `table_category` (`cat_id`, `Cat_name`) VALUES
(7, 'Desktop'),
(8, 'Mobile'),
(9, 'Laptop'),
(10, 'Tab'),
(12, 'DSLR'),
(13, 'tuhin'),
(14, 'Farewell'),
(15, 'Panda');

-- --------------------------------------------------------

--
-- Table structure for table `table_comment`
--

CREATE TABLE IF NOT EXISTS `table_comment` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(255) NOT NULL,
  `c_email` varchar(255) NOT NULL,
  `c_url` varchar(255) NOT NULL,
  `c_message` text NOT NULL,
  `c_date` date NOT NULL,
  `post_id` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `table_comment`
--

INSERT INTO `table_comment` (`c_id`, `c_name`, `c_email`, `c_url`, `c_message`, `c_date`, `post_id`, `active`) VALUES
(1, 'tuhin', 'tuhinsshadow@gmail.com', '', 'this is a nice article', '2017-02-21', 17, 1),
(2, 'nishat', 'babydollnishat@gmail.com', '', 'this is very good.', '2017-02-21', 17, 1),
(3, 'Md .Saiduzzaman Tuhin', 'tuhinsshadow@gmail.com', 'www.renewale.com', 'Very very nice article', '2017-02-21', 17, 1),
(4, 'Md .Saiduzzaman Tuhin', 'tuhinsshadow@gmail.com', 'www.renewale.com', 'Very very nice article', '2017-02-21', 17, 1),
(5, 'kawsar', 'kawsar@gmail.com', '', 'nice work', '2017-02-21', 17, 1),
(6, 'kawsar', 'kawsar@gmail.com', '', 'nice work', '2017-02-21', 17, 1),
(7, 'Himel', 'himekl@gmail.com', '', 'You lookin so cool dude.....', '2017-02-21', 14, 1),
(8, 'Himel', 'himekl@gmail.com', '', 'You lookin so cool dude.....', '2017-02-21', 14, 1),
(9, 'Himel', 'himekl@gmail.com', '', 'You lookin so cool dude.....', '2017-02-21', 14, 1),
(10, 'nazmul', 'nazmul@gmail.com', 'www.renewale.com', 'this is kala panda', '2017-02-21', 16, 1);

-- --------------------------------------------------------

--
-- Table structure for table `table_footer`
--

CREATE TABLE IF NOT EXISTS `table_footer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `table_footer`
--

INSERT INTO `table_footer` (`id`, `description`) VALUES
(1, 'Copyright @2017 Md. Saiduzzaman Tuhin (All Rights Reserved)');

-- --------------------------------------------------------

--
-- Table structure for table `table_login`
--

CREATE TABLE IF NOT EXISTS `table_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `table_login`
--

INSERT INTO `table_login` (`id`, `username`, `password`) VALUES
(1, 'admin', 'a41acc7effe601de1dc2099a4e2fdd7c');

-- --------------------------------------------------------

--
-- Table structure for table `table_post`
--

CREATE TABLE IF NOT EXISTS `table_post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_title` varchar(255) NOT NULL,
  `post_description` text NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `tag_id` varchar(255) NOT NULL,
  `post_date` varchar(255) NOT NULL,
  `year` varchar(4) NOT NULL,
  `month` varchar(2) NOT NULL,
  `post_timestamp` varchar(255) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `table_post`
--

INSERT INTO `table_post` (`post_id`, `post_title`, `post_description`, `post_image`, `cat_id`, `tag_id`, `post_date`, `year`, `month`, `post_timestamp`) VALUES
(5, 'tuhin', '<p>i love myself</p>\r\n', '5.jpg', 8, '4', '2017-02-16', '2017', '02', '1487199600'),
(6, 'nishta', '<p>fgdrgfdgfx rsgf ggr</p>\r\n', '6.jpg', 13, '4', '2017-02-16', '2017', '02', '1487199600'),
(7, 'CSTE 1', '<p>Computer Science And Telecommuniucation Engineering</p>\r\n', '7.jpg', 9, '7,3', '2017-03-16', '2017', '03', '1487199600'),
(8, 'A Simple Project On PHP', '<p>i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.i am just loving this language.</p>\r\n', '8.jpg', 7, '4,8,5', '2017-04-17', '2017', '04', '1487286000'),
(9, 'Post Number 1', '<p>Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1Post Number 1</p>\r\n', '9.jpg', 9, '4,7', '2017-02-18', '2017', '02', '1487372400'),
(10, 'Post Number 2', '<p>Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2Post Number 2</p>\r\n', '10.jpg', 8, '5', '2016-11-18', '2016', '11', '1487372400'),
(11, 'Post Number 3', '<p>Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3Post Number 3</p>\r\n', '11.jpg', 9, '8', '2016-10-18', '2016', '10', '1487372400'),
(12, 'Post Number 4', '<p>Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4Post Number 4</p>\r\n', '12.jpg', 9, '4,8,5', '2017-05-18', '2017', '05', '1487372400'),
(13, 'Post Number 5', '<p>Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5Post Number 5</p>\r\n', '13.jpg', 8, '8', '2017-02-18', '2017', '02', '1487372400'),
(14, 'Post Number 6', '<p>Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6Post Number 6</p>\r\n', '14.jpg', 10, '4', '2017-05-18', '2017', '05', '1487372400'),
(15, 'Post Number 7', '<p>Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7Post Number 7</p>\r\n', '15.jpg', 8, '8', '2017-02-18', '2017', '02', '1487372400'),
(16, 'Nazmul & Panda', '<p>Mother fucker. Friends Fucker. Bolod fucker. Panda fucker .</p>\r\n', '16.jpg', 15, '9', '2017-02-18', '2017', '02', '1487372400'),
(17, 'This is the last test post.', '<p>This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.This is the last test post.</p>\r\n', '17.jpg', 9, '4', '2017-02-21', '2017', '02', '1487631600');

-- --------------------------------------------------------

--
-- Table structure for table `table_tag`
--

CREATE TABLE IF NOT EXISTS `table_tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(255) NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `table_tag`
--

INSERT INTO `table_tag` (`tag_id`, `tag_name`) VALUES
(3, 'Pen'),
(4, 'Book'),
(5, 'Khata'),
(7, 'kutta'),
(8, 'haramzada'),
(9, 'Kala Panda');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
